const RELEASE_INTEGRITY = {"./":"sha256-+FF23BpmMmtSMSI2a9hlGeb0kAU8A68nMm5VpG7i0J0=","./index.html":"sha256-+FF23BpmMmtSMSI2a9hlGeb0kAU8A68nMm5VpG7i0J0=","./styles.css":"sha256-JljoRWkP9/CjzS48gm5NXvfEJwLyAIVrSYPqxSHz6NE=","./app.js":"sha256-QPycUBZ2dQl6OizbfYVUmpekzerDgMmvUCxQhiq88wU=","./pose-assets.js":"sha256-b5rwvm47cpyXcMaxxr60iC+xUiknnBs37xc++DC12hE=","./model-profiles.js":"sha256-LkoIe9JTPrOh0C4FcjUucukSmG0qExMsgCGP4x7F9qA=","./volleyball-cue.js":"sha256-rXi77yX3yvidKufgfrwbAE6Jxn77brLYtAU3dZznCYE=","./pose-runtime.js":"sha256-xKW5vcAe4og3Y+cd+MGirVbpZXUDUmj+0baHCjY2lLg=","./pose-presence.js":"sha256-adGv+b5K3gNNdfZQDblS1ePTJCNohZ8MouHgObZAxew=","./basketball-shot.js":"sha256-xI04meFi+YV22VwrYSdJVG7V7BDIz7bRYwuj4p9M370=","./shot-feedback.js":"sha256-0iSQdTxuJeC7pmKdXlh8IutD7cyaX4/z5iOUNv9N38E=","./shot-history.js":"sha256-mQydLa6XVxm/xivm/yMLRC4aapTXh+sKyr4UzbeoRK0=","./shot-history-ui.js":"sha256-rOY8BUu4aciYnMDwGjtWyPJBJZ3Oo5rBdiYg4swhsIw=","./pose-ui.js":"sha256-q3g3XS0EK02vtNRQtHCsA4udLJ0W83PjpMf6+O9AsHA=","./pose-worker.js":"sha256-zBntg9oEaIPjCTZxP2SoRam1xOGvXmWuBD4QKTVpw4A=","./classroom-model.js":"sha256-5Wf//d1cyu5ipUxE2sQ7amDVnSL02qIW9/IHkLl7jkg=","./paps-criteria-data.js":"sha256-K2WGKEMAfN2FAZo0Ppi0xUlbuq5fbsqx/AkdYjX3tIg=","./paps-criteria.js":"sha256-7XB6yn0BJuomFCZkZKEStG7eDD1KD763jwY7broTE4g=","./paps-bmi-criteria-data.js":"sha256-/SChBNdfo7twqknCcvcrIxd4sh3n9ouHUNf1lK4gQfE=","./paps-bmi-criteria.js":"sha256-JAPn6JaB7oGFB4qzZAlRAvMfoQ86pLyfYzTzfD5Asgs=","./paps-program-selection.js":"sha256-wabQtCQEHaVFd9+LVU8OU8N/yGywhlcH5w/VZBRVDcM=","./paps-reports.js":"sha256-wHMpwqufgpz1duuWG5WhmmLlYdKhDfTHhv9NEpzC1nE=","./pe-curriculum.js":"sha256-1U6AyupPkB701FiLsJMKrsa1cQ/8824zC9z4hMjebbo=","./teacher-evaluations.js":"sha256-+GFrF6ziSzR8k0gemgA330VtI+2AG0DAxu4QtkukhoU=","./exercise-routines.js":"sha256-Oyz5b1/JoRAtspWI2Gw58xxmqnowpPU6yPDZcGjhTzs=","./gps-missions.js":"sha256-KYr1Hl9TrUw+eGluD/onwffvbxRUHJ+5Y/5uvtNO+xU=","./qr-missions.js":"sha256-uuUR5Yjh9//Aqu2rlUDTqzd1RTbHLy1+8tPN7BzQ0QA=","./tactics-board.js":"sha256-96CuSsYWg4LmR7KxA6h6NYV/HlUHnOtrLqH5VXCDW2s=","./tactics-sharing.js":"sha256-PqMiGJqD/6gtVf6TlQlOFORR4zF4Xw2Npamxv/PZZGc=","./tactics-search-local.js":"sha256-05BDv1GL3bgY9klBEMe/B5010Du0iTA/F4+5OvCK5xo=","./tactics-team-request.js":"sha256-T+pwuMQNeGhCFbCrA2AKs7besxoQvDa7JGYkz6h822U=","./tactics-local-prompt.js":"sha256-2MKzSA9EMrx1qVW9jMcY0Pn5BIH6cgRsjmizwlj5HjM=","./tactics-local-advisor.js":"sha256-Z/7/wom205r16ZlKBnj8NNG+EAezyMWmVRXFmE2t2Qs=","./tactics-student-ui.js":"sha256-9lyCCqXthCDE1vhvt3nmrAqFaSzTw7LRGidRbTc7k8Q=","./vendor/wllama-v3/index.js":"sha256-//2VwWyhkfMfQwNmSgUYnEPQyyDFK2cnbATohXsTi2Q=","./vendor/wllama-v3/wasm/wllama.wasm":"sha256-eaxb6Re3HVBXGk9YRDap9rr2tuV3GdCU7YvZUOmmV4A=","./vendor/wllama-v3/compat/wllama.js":"sha256-lCBip0lXkKMXBhsnprzSvTskfi3e9ToGm69auwcoR1g=","./vendor/wllama-v3/compat/wllama.wasm":"sha256-Nd+MHi99vXS46LAQVPufH76Gz1ZpRfv0zvOWWFWouS4=","./vendor/hf-tokenizers/tokenizers.mjs":"sha256-HEqEj4YVYgHAM9bNCMTPga4QiFUqzsM2fzHvCG7fWvA=","./vendor/qwen-tokenizer/tokenizer.json":"sha256-wDghF+oynN8JcEETL21zWSS2l5JNb2/DlFcT6WzodTk=","./vendor/qwen-tokenizer/tokenizer_config.json":"sha256-W11PZdCs07LVajW1bTdKNsvByPpc87P+u7+r8i81lYM=","./vendor/noble-hashes/sha256.js":"sha256-gyW+1nGhY5n0J8bb1/XnKsVnxSPO7A6tFVHH5/+U7Mg=","./vendor/noble-hashes/_md.js":"sha256-btqIte1FYk7HxbzGfBWh1hvHceEvWtsdiAsAOs+5Mvc=","./vendor/noble-hashes/_assert.js":"sha256-FYLle8xwqhKOHAt94rQQFATZxzndjv7BZjReI7o1Xgw=","./vendor/noble-hashes/utils.js":"sha256-3iwF/00Ro4st5YRkqtspsOdf2fiHjAZR6/2eDmDrAZs=","./vendor/noble-hashes/crypto.js":"sha256-khHQJsXSHmDgEm3W8BFQ2H2lunJhuPRoIVwSZDcv9aU=","./tactics-tools-ui.js":"sha256-ssKLjswF9XSLOihuwvwv9EnAF3NKwwfaWBu7bHcxltk=","./wearable-bridge.js":"sha256-/24SsDODd6bq46t70HUOKKHgHzJxenorQZp/v7QOh68=","./classroom-tools-ui.js":"sha256-92k9unyLnUEk2f5IsIg5HIElhjpuhT/0e220cPPqPZs=","./classroom-repository.js":"sha256-Ym7bxqJcKgFfJyHpg7WuYke+z1DvbCTBe2pOIMxRGHo=","./classroom-sync.js":"sha256-YHoQZD+vbftmFmDqekiJyiuADyi+arnhfsjdT7KqrSw=","./classroom-ui.js":"sha256-6ibvfe1pFgyFriUm1Wcu9cjkA76bcxSqaLdAWftALu8=","./qrcode-generator.js":"sha256-GK45n4EYK8nekW6cd7GV3yDMWNby1VpisIWimfG/F4A=","./local-vault.js":"sha256-gt3srpk1NoSWXVUBrttQrnuFnHJ/jPHvmdXvLQ5qzKM=","./clip-repository.js":"sha256-K8U2Glwkj+mJpe6JtS0PozyqXarSIS2kSqkK0B2iiU4=","./webm-muxer.js":"sha256-fbIoDBIt2x3bo+ZnkxD+cbX7xdBi7uV0ezzrpVr3vgw=","./clip-exporter.js":"sha256-q3VHYOtfF2YnClfLgG+Hns++3q5r27KkHBSQbhPgqls=","./timeline.js":"sha256-ws8qzlN67HFrlv2wthefIh5OoSvzNhFG961mmpKlr34=","./frame-buffer.js":"sha256-+EudgxEczTjgv+1hxr5y7XCkRyJP7WE+RslPVIcaX4s=","./device-check.js":"sha256-pz+Gx/ErzgRgtWqkhBemthYLgWkbRBRPwg7/Tml2Las=","./device-check-ui.js":"sha256-j++ZbYTgJ4tRJMqZ8CvU5Ua5ckQHpKSWNE63MhUxS2g=","./manifest.webmanifest":"sha256-Mc0H4gNAJltejgkDWTbMqbiZ33z41NyganNpz7sfpd4=","./icon.svg":"sha256-09IlCVL8w3JgrjkzdyciHA0dS1j26uugnwHp9ij6BKY=","./icon-192.png":"sha256-WIAYcZFCG0gYmH0k1bkUQllJOL5Ntffigw1GKlV+9XA=","./icon-512.png":"sha256-n9VnNgX38qeogt7FG1v94mVI2Osat5+1EaQd0W1VR6w="};
// Increment this version whenever any app-shell resource changes.
const CACHE_NAME = 'pe-loop-shell-release-school-v1-rc1';
const APP_SHELL = ['./', './index.html', './styles.css', './app.js', './pose-assets.js', './model-profiles.js', './volleyball-cue.js', './pose-runtime.js', './pose-presence.js', './basketball-shot.js', './shot-feedback.js', './shot-history.js', './shot-history-ui.js', './pose-ui.js', './pose-worker.js', './classroom-model.js', './paps-criteria-data.js', './paps-criteria.js', './paps-bmi-criteria-data.js', './paps-bmi-criteria.js', './paps-program-selection.js', './paps-reports.js', './pe-curriculum.js', './teacher-evaluations.js', './exercise-routines.js', './gps-missions.js', './qr-missions.js', './tactics-board.js', './tactics-sharing.js', './tactics-search-local.js', './tactics-team-request.js', './tactics-local-prompt.js', './tactics-local-advisor.js', './tactics-student-ui.js', './vendor/wllama-v3/index.js', './vendor/wllama-v3/wasm/wllama.wasm', './vendor/wllama-v3/compat/wllama.js', './vendor/wllama-v3/compat/wllama.wasm', './vendor/hf-tokenizers/tokenizers.mjs', './vendor/qwen-tokenizer/tokenizer.json', './vendor/qwen-tokenizer/tokenizer_config.json', './vendor/noble-hashes/sha256.js', './vendor/noble-hashes/_md.js', './vendor/noble-hashes/_assert.js', './vendor/noble-hashes/utils.js', './vendor/noble-hashes/crypto.js', './tactics-tools-ui.js', './wearable-bridge.js', './classroom-tools-ui.js', './classroom-repository.js', './classroom-sync.js', './classroom-ui.js', './qrcode-generator.js', './local-vault.js', './clip-repository.js', './webm-muxer.js', './clip-exporter.js', './timeline.js', './frame-buffer.js', './device-check.js', './device-check-ui.js', './manifest.webmanifest', './icon.svg', './icon-192.png', './icon-512.png'];
const shellUrls = new Set(APP_SHELL.map(path => new URL(path, self.registration.scope).href));

self.addEventListener('install', event => {
  // A failed or partial download must never replace the working version.
  event.waitUntil(caches.open(CACHE_NAME).then(cache =>
    cache.addAll(APP_SHELL.map(path => new Request(path, { cache: 'reload', integrity: RELEASE_INTEGRITY[path] })))
  ));
});

self.addEventListener('activate', event => {
  // Natural activation waits until the old worker has no controlled clients.
  event.waitUntil(caches.keys().then(keys => Promise.all(keys
    .filter(key => key.startsWith('pe-loop-shell-') && key !== CACHE_NAME)
    .map(key => caches.delete(key)))));
});

self.addEventListener('message', event => {
  if (event.data?.type === 'CHECK_SHELL' && event.ports[0]) {
    event.waitUntil((async () => {
      const cache = await caches.open(CACHE_NAME);
      const entries = await Promise.all(APP_SHELL.map(path => cache.match(path)));
      event.ports[0].postMessage({ ready: entries.every(response => response?.ok) });
    })());
    return;
  }
  if (event.data?.type !== 'APPLY_UPDATE' || !event.source?.id || !event.ports[0]) return;
  event.ports[0].postMessage({ ok: false, reason: 'close-to-update' });
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  const scopeUrl = new URL(self.registration.scope);
  const isAppNavigation = request.mode === 'navigate' &&
    (url.pathname === scopeUrl.pathname || url.pathname === new URL('index.html', scopeUrl).pathname);
  if (!isAppNavigation && !shellUrls.has(url.href)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(isAppNavigation ? new URL('index.html', self.registration.scope).href : request);
    // Never fill a missing shell asset from a different deployment version.
    return cached || Response.error();
  })());
});
